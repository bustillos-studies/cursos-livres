<?php

    // Require do Script Autoload: Responsável por fazer todo o carregamento automático de todas as classes contidas dentro da arquitetura do projeto.
    require_once "../vendor/autoload.php";

    // Carregando a classe Route dentro do namespace "app" e criando um objeto atribuindo-o a uma variável.
    $route = new \app\Route;

    

?>